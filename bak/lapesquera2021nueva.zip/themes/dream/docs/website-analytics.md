# Website Analytics

Now, the dream theme only support [Google Analytics](https://www.google.com/analytics/).

In `config.toml`, set:

```toml
googleAnalytics = "..."
```

Done.
