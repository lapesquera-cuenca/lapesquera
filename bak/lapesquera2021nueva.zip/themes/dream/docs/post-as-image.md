# Post as Image

This is an **Experimental Feature**.

You will find a label named `Save as image` in your single post page (above Disqus).

Click it, the post's screenshot will be downloaded.
