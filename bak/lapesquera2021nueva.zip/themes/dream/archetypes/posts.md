---
title: {{ replace .TranslationBaseName "-" " " | title }}
date: {{ .Date }}
lastmod: {{ .Date }}
author: Author Name
# avatar: /img/author.jpg
# authorlink: https://author.site
cover: /img/cover.jpg
categories:
  - category1
tags:
  - tag1
  - tag2
draft: true
---

Cut out summary from your post content here.

<!--more-->

The remaining content of your post.
