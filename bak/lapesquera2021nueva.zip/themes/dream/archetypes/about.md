---
title: {{ replace .TranslationBaseName "-" " " | title }}
date: {{ .Date }}
lastmod: {{ .Date }}
draft: true
---

Cut out summary from your post content here.

<!--more-->

The remaining content of your post.
