---
title: Subasta de San Roque y la Virgen.
date: 2020-08-16T18:48:12+01:00
lastmod: 2020-08-16T18:48:12+01:00
author: Crescencio Martinez
avatar: /img/author.jpg
# authorlink: https://author.site
cover: /img/andasSanRoque.jpg
categories:
  - verano
tags:
  - fiestas
  - musica
  - san roque
draft: true
---

##

Se celebra cada 16 de agosto después de la procesión.



Se desconoce el origen o costumbre de hacer esta subasta de las andas, ya que no hay hechos escritos o relatos que se puedan contratar por lo cual debemos suponer, que debe ser desde tiempos remotos. Lo que conozco y he vivido, así lo describo a continuación: La subasta de andas se realiza todos los años el día 16 de agosto, festividad de nuestro patrón San Roque.

Una vez finalizada la Santa Misa en su honor, se inicia la procesión saliendo de la Iglesia parroquial las imágenes; primero San Roque y detrás la Santísima Virgen, recorriendo el siguiente itinerario por La Pesquera: Calle Nueva, travesía de San Roque, calle de San Roque, Plaza Mayor, calle Arrabal y subiendo por la calle de la Iglesia se llega de nuevo a la Plaza Mayor, finalizando delante de la puerta del templo.

Los pasos procesionales son portados a hombros, seguidas por gran multitud de fieles con fervor y devoción, acompañados con la banda de música, canticos y el estruendo de tracas y cohetes.

Llegados a este punto, tiene lugar el comienzo de la subasta, que se realiza de la siguiente forma: Cada anda tiene cuatro varas: derecha delantera, izquierda delantera, derecha de atrás e izquierda de atrás. Cuatro personas ocupan cada una de ellas, bien sea por ofrecimientos a la imagen que llevan, por favores recibidos de la misma, como donativo o por voluntad propia. Se inicia la subasta ofreciendo una cantidad de dinero por la vara que llevan.

El subastador, es una persona que desde la entrada a la puerta de la Iglesia y con voz que pueda oírse a distancia, enumera y repite constantemente la cantidad pujada para cada vara. Por ejemplo:

![](/img/subasta.jpg)  

“20 € tiene la vara derecha delantera y

15 € tiene la vara izquierda delantera.

10 € tiene la vara derecha de atrás y

10 € tiene la vara izquierda de atrás.”

Si hay otra persona que ofrezca más dinero por cualquier vara, se apodera de la misma quitándosela al que la tenia. El subastador va repitiendo las cantidades que tiene cada vara, y de vez en cuando dice: “un paso adelante” y así, entran a la Iglesia el trono procesional las cuatro personas que mayor cantidad han ofrecido, con vivas a la imagen que portan. Desconozco la fecha exacta que empecé de subastador, pero según la fotografía de Goyo Murciano, el día de San Roque del año 1980, ya aparezco haciendo la subasta, aunque pienso que empecé algún año antes. Entonces se hacía la subasta a viva voz y memorizando los importes. Era la costumbre de los subastadores de la época, entre los que se encontraban: Jesús Muñoz, Amador Ponce Sierra, Eduardo Martínez Lagunas, Joaquín Sáez y Cirilo Huerta Ponce. Desde que soy subastador, desde finales de los setenta, año tras año gracias a Dios y a San Roque, sigo haciendo la subasta con la colaboración de los que siempre ayudan: Eloy Marco Gadea, José Luis Bono Palomares, Emiliano Palomares Martínez, Lucio y Máximo Villena y otros. Pero ahora, eso sí, con micrófono y altavoces. Al concluir la subasta de las imágenes, tiene lugar otra subasta de objetos que voluntariamente han ofrecido los fieles. El importe alcanzado en la subasta sirve para colaborar en los ingresos y sufragar gastos de la parroquia. Entre los objetos de la subasta se encuentras: tiestos con plantas tales cómo alábega (muy deseada por su fragancia y vistosidad) y otras plantas ornamentales; imágenes, cuadros, fotografías o labores de bordados y ganchillos.

El sistema de subasta es el mismo que se hace con las andas. Así, se acaba con la tradicional subasta de andas cómo de ofrendas.