---
title: Mayos a las mozas
date: 2020-05-01T18:48:12+01:00
lastmod: 2020-05-01T18:48:12+01:00
author: Crescencio Martinez
avatar: /img/author.jpg
# authorlink: https://author.site
cover: /img/mayo-moza.jpg
categories:
  - primavera
tags:
  - mayos
  - musica
draft: true
---
![](/img/mayo-moza.jpg)  

Gracias a Dios que llegué  
gracias a Dios que he llegado,  
a la puerta de esta dama  
donde yo me he enamorado.  
  
Parece que me tardé  
parece que me he tardado,  
en cada pie una hora  
en cada pasito un año.  
  
Despierta si estas dormida  
despierta si estas soñando,  
que no está bien que tu duermas  
velando tu enamorado.  
  
Despierta si estas dormida  
de ese sueño tan profundo,  
que no está bien que tu duermas  
velando la sal del mundo.  
  
Despierta si estas dormida  
de ese sueño tan profundo,  
que no está bien que tu duermas  
velando la sal del mundo.  
  
(* cambio de tono)  
Y ahora señora, si me das licencia,  
pintare tu garbo, de pies a cabeza.  
  
Ese es tu cabeza, tan re chiquitita,  
en la cual se forma, una margarita.  

![](/img/1Mayo.jpg) 
  
Tu mata de pelo, de oro es la madeja,  
pues en ella el Sol, sus rayos refleja.  
  
Tu frente espaciosa, es campo de guerra,  
donde el rey Cupido, plantó su bandera.  
  
Esas dos tus cejas, son tan arqueadas,  
arcos celestiales, sobre tu mirada.  
  
Esos dos tus ojos, luceros del alba,  
que cuando los abres, la noche se aclara.  
  
Tu nariz aguda, con filo de espada,  
que a los corazones, los hiere y traspasa.  
  
Esos son tus labios, a la filigrana.  
Tus dientes menudos, que roban la plata.  
  
Tu lengua parlera, es la que me engaña,  
con risa halagüeña, con dulces palabras.  
  
Ese hoyo que tienes, en esa barbilla,  
ha de ser sepulcro, para el alma mía.  
Esas tus orejas, con lindos pendientes,  
son los que te adornan, tu cara y tu frente.  
  
Ese cuello de alabastro, es donde yo me recreo,  
que no duermo ni descanso, el día que no lo veo.  
  
Esos dos tus brazos, dos cadenas son,  
con los que aprisionas, a mi corazón.  
  
Tus manos tan finas, son maravillosas,  
que en flores convierten, todo lo que tocas.  
  
Esos dos tus pechos, son dos fuentes claras,  
donde yo bebiera, si tú me dejaras.  
  
Tu cintura niña, tan proporcionada,  
que parece un junco, nacido en la playa.  
Ya estamos llegando, a partes ocultas,  
nadie me responda, en esta pregunta.  
Esos dos tus muslos, de oro son macizos,  
son los que sostienen, todo el edificio.  
  
Esas tus rodillas, son bolas de nácar,  
y tus pantorrillas, pilares de plata.  
  
Zapatitos blancos, las medias de seda,  
las hebillas de oro, quien te las pusiera.  
  
Tus pies y tus manos, van tan al compás,  
que la Virgen Pura, no pudo hacer más.  
Ya tienes pintada dama, todas tus lindas facciones,  
y ahora te falta el mayo, para que te las adorne.  
  
El mayo que quieras, dímelo y declara,  
que el pintor no quiere, agraviarte en nada.  
Cuando no respondes, ni me dices nada,  
Es señal que tengo, la licencia dada.  
  
Señorita (nombre), tenga usted por mayo,  
al señorito (nombre), si es que es de su agrado.  
  
Si el mayo no ha sido a gusto, perdona mi atrevimiento,  
que no soy hombre tan justo, que adivine el pensamiento.  
  
Quiérelo madama, quiérelo doncella,  
que el también te quiere, sino te quisiera,  
no se desvelara, como se desvela.  
  
Mis compañeros señora, se despiden y se van,  
y yo también me despido, sino que es lo que dirán.  
Mis compañeros señora, se despiden de uno en uno,  
y yo también me despido, porque no quede ninguno.  
Mis compañeros señora, se despiden de dos en dos,  
y yo también me despido, señora adiós, adiós.  
