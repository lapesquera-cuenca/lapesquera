---
title:  ¡De Navidad hasta San Antón aguilandos son!
date: 2020-12-24T16:44:31+01:00
lastmod: 2020-12-24T16:44:31+01:00
author: Crescencio Martinez
avatar: /img/author.jpg
# authorlink: https://author.site
cover: /img/navidad.jpg
categories:
  - invierno
tags:
  - navidad
  - hogueras
draft: true
---


## De Navidad hasta San Antón

¿Y por qué este título? A continuación intentaré relatar, con mi mejor voluntad e intención, un período de tiempo entre diciembre y enero, del cual me queda un grato recuerdo y cierta nostalgia.  
Después de finalizar las faenas del otoño (vendimia, recogida de **_almendros_** y de productos del huerto) llega diciembre y con él, el invierno. Tiempo de reposo y sosiego, de heladas y escarchas matinales, de mucho frío y algún día de nieve. Pero también es tiempo de calor hogareño, cuando en las cocinas, estancia que servía par todo, en la chimenea ardían con sus llamas fantasmales las chisporroteantes cepas de viña y los troncos de carrasca  y donde nunca faltaba un caldero con agua caliente: con aquel olor a leña quemada que desprendían las estufas en cuyo derredor nos reuníamos la familia con algún vecino, disfrutando al **_senochar_** las largas noches de invierno y donde nuestros mayores nos dejaban boquiabiertos contando sus  historias y vivencias sin dejar de lado sus tareas; Ellas, tejiendo con lana jerséis o calcetines; ellos, desgranando las panochas de maíz para los animales o manipulando el esparto, haciendo sogas, **_vencejos_** o **_pleita_**,  con la cual, a su vez, confeccionaban espuertas, cuévanos para las faenas del campo y serones para el transporte sobre las  caballerías.  
Y todo esto, a la luz de un candil de aceite o del carburo minero. Nada de radio ni televisión, ya que la luz eléctrica fue instalada el año 1948, algo que vivimos como un gran acontecimiento.

![](/img/matanza2.jpg)

También era el tiempo de las **_matazones_**, cuando se sacrificaba el cerdo, criado y cebado durante todo el año. Ese día era un gran acontecimiento familiar y de amigos. La **_matazón_** se desarrollaba del siguiente modo:  
A primera hora de la mañana llegaba el momento de sacrificar al cerdo. Entre unos cuantos (ya que el animal solía pesar de ocho a doce arrobas) lo tumbaban sobre una mesa  y entonces el tío Marcelino Lorente, **_matagorrinos_**, le pinchaba en el cuello para desangrarlo. Una de las mujeres de la casa, con un hermoso lebrillo, iba recogiendo la sangre sin dejar de removerla para que no se coagulara. Sangre que serviría, junto con la cebolla cocida el día anterior y con la manteca y las correspondientes especias para hacer las sabrosas morcillas.  
![](/img/matanza1.jpg)  
Se churrascaba el cerdo con **_aliagas_** encendidas, que servían para pelar y afeitar los pelos del animal. Una vez éste bien lavado, el matador lo **_despiazaba_**: perniles, lomos, costillas. Todo se aprovechaba. Hay un dicho que reza: _“Del cerdo me gusta hasta sus andares_”.  
Mientras tanto, en el fuego ya había un gran parrilla con lo cortado del cerdo: rabo, oreja y alguna magra. Bien asado, se comía con todos reunidos, sin faltar el porrón de vino.  
Al mediodía era el momento festivo de todos juntos: la hora de comer el suculento y tradicional  **_MORTERUELO_**: ¡delicioso!, o las **_almortas_**, sin olvidar la fritada de tocinillo magroso fresco. ¡Cómo disfrutábamos todos!  
Después llegaba la faena de las mujeres: limpiar las tripas del animal (que servirían para hacer los embutidos), partir las carnes, adobarlas, y a continuación hacer las longanizas, **_güeñas_** y morcillas.  Así transcurría el día de **_matazón_**.

Con el transcurso de los días llega la NAVIDAD, tiempo de villancicos y aguilandos, De **_tortillas_** de aguardiente y pastelillos de boniato o calabaza.

De bailes de JOTA.  
Los **_aguilandos_** eran la ilusión de la chiquillería: ir de casa en casa con una pequeña zambomba pidiendo el **_aguilando_**, pero tenías que ganártelo cantando un villancico, como éste: “Si me da usted el aguilando, no me lo dé usted en bellotas, démelo usted en tortas finas, llevo las alforjas rotas”. Te solían dar lo que había en la casa: **_almendros_**, nueces y, alguna vez, diez céntimos (de peseta).

![](/img/jota.jpg)

JOTAS.-  El que no lo hay vivido ni visto no puede imaginar lo que es vivir en un tiempo de posguerras (la civil y la mundial) pleno de dolor y penurias, aprovechar cualquier momento para vivirlo con una chispa de humor y alegría y compartirlo con los demás.  
¿Os imagináis un grupo de mujeres y hombres, generalmente todos casados, con una zambomba (hecha con la piel de una res, colocada muy tirante, con una cañita en el centro sobre un corcho de colmena, la cual se hacía sonar humedeciendo la mano con agua y haciéndola resbalar sobre la cañita con el puño cerrado), un almirez, castañuelas  y una botella vacía de anís del mono cuyas protuberancias se rascaban con el mango de una cuchara. Ésta era la música que acompañaba las voces de hombres y mujeres que desgranaban unas coplillas tan sencillas y tiernas como eran las JOTAS, aunque a veces alguna de ellas tuviese un sentido picaresco.

![](/img/anis.jpg)  
Este grupo de joteras y joteros solían ser casi siempre las mismas personas, buena gente,  que disfrutaban reuniéndose en cualquier casa, acogiendo y haciendo disfrutar a cuantos llegaban, aunque a veces el espacio era muy reducido.  
Desde donde me alcanza la memoria, el grupo que más destacaba en estos bailes lo componían: El tío Bernardo y la tía Encarnación; el tío Avelino y la tía Felisa; la tía Dorotea de Emiliano Palomares; la tía Irene y el tío Martín:; la tía Inocencia de Alberto; y algunos más. Estos eran el grupo de cantores y tocadores, ya que bailar, bailaban los que querían y sabían bailar jotas. Entre los que mejor bailaban la JOTA yo destacaría a la tía Elvira de Francisquete o la tía Ezequiela de Murciano: ellas parecían muñecas con aquellos movimientos suaves y armoniosos. Y ellos, digamos más enérgicos, pero no menos controlados: Miguel García, Fabriciano Murciano, Avelino Mares, Salomé Iniesta y otros y otras que lo hacían muy bien.  
Estos bailes de jotas se componían de tres o cuatro parejas de bailadores y se iniciaban con un vals corrido o un pasodoble y en cierto momento se cambiaba el ritmo del baile y se seguía al ritmo de jota. Se cantaban cuatro o seis letras de jota y una que era de despedida. Al final de este relato transcribo algunas de las letras que todavía recuerdo de estos bailes de JOTA que se prolongaban hasta San Antón.

Llega  SAN ANTÓN,  17 de enero.  
Se inicia la fiesta la víspera, el día 16\. Como en todas las casas había animales y San Antón es el patrón de todos ellos, era costumbre ir al campo y traer leña para hacer la hoguera delante de la casa: pino, romero, cualquier ramaje que pudiera hacer más grande la hoguera.  
Se encendían después de cenar y las había grandiosas. La hoguera se consideraba una petición al Santo para que protegiera las patas de caballerías y otros animales domésticos. Había hogueras donde daban “**_puñao_**” (tostones de trigo remojado y frito con sal, y garbanzos tostados). Normalmente lo daban en la hoguera de la casa donde aquel año habían comprado alguna caballería. Los chavales las recorríamos una y otra vez, siempre con el ensordecedor ruido de las esquilas y cencerros que llevábamos atados a las espaldas.

![](/img/hogueras.jpg)  
Sobre las brasas que quedaban de las hogueras los vecinos que las habían hecho solían asar patatas, cebollas, algún choricillo y morcilla, sin faltar el vino nuevo sacado de la tenaja que había sido elaborado en el **_jaraíz_**.  
El día 17 por la tarde solía haber carrera de caballerías por la calle y con el baile correspondiente finalizaba la fiesta.

Y aquí finaliza también este relato mediante el cual, con mis mejores deseos y buena voluntad, he querido reflejar,  para que no desaparezcan en el olvido (y porque recordar es volver a vivir), unos tiempos pasados que dejaron marcada en nuestra vida la huella humana de los que nos precedieron.



## Letras de los “bailes de Jota”

Se inicia este baile al ritmo de VALS CORRIDO:

_Esta mañana temprano cogí mi caballo y me fui a pasear_  
_tuve que cruzar la ría de Villagarcía que es puerto de mar._

_Yo te daré, te daré niña hermosa_  
_te daré una cosa_  
_una cosa que yo solo sé. CAFÉ._ (Se repite desde _Yo te daré_)

A continuación se cambia a ritmo de jota y entre jota y jota, se cantaba una seguidilla y se hacia el paseíllo bailando:

_El que quiera jota, jota_  
_y el que fandango, fandango,_  
_y el que quiera seguidillas_  
_en el bolsillo las traigo._  
**_Seguidilla_**  
_A tu madre le pido_  
_y a ti te saco_  
_los cuartos del bolsillo_  
_para tabaco._

_Por esta calle que vamos_  
_la riegan con agua y rosas_  
_y por eso la llamamos_  
_la calle de las hermosas._

**_Seguidilla_**  
_Arrincónamela_  
_y échamela al rincón._  
_Si es casada, casada,_  
_y si es soltera, mejor._

_De tu puerta hasta la iglesia_  
_voy a plantar una parra,_  
_por si quieres ir a misa_  
_no te dé el sol en la cara._

**_Seguidilla_**  
_Al salir el sol_  
_te quisiera ver,_  
_pero veo, niña,_  
_que no puede ser._

_Si tuvieras olivares_  
_como tienes fantasía_  
_el río de Manzanares_  
_por tu puerta pasaría._

**_Seguidilla_**  
_Y a tu padre, morena,_  
_se lo voy a decir,_  
_que te ves con el Cabo_  
_ de la Guardia Civil._

_Esos dos que están bailando_  
_qué bien que llevan el son_  
_y según tengo entendido_  
_la novia y el novio son._

**_Seguidilla_**  
_Con el sí, sí, sí. Con el no, no, no._  
_Si tú tienes huerto, jardín tengo yo._  
_Si tú no lo riegas, yo lo regaré_  
_y las flores que eche yo las cogeré_.

Y al final, la despedida:

_Si tuviera una naranja_  
_contigo la partiría,_  
_pero como no la tengo_  
_allá va la despedida_.  
“BAILES DE JOTA” (2)  
Se inicia con ritmo de PASODOBLE:

**Pasodobles:**

_Después de tanto tiempo_  
_nos hemos licenciado._  
_Volvemos a nuestra casa_  
_a ver padres y hermanos._

_Después de tanto tiempo_  
_y haber cumplido el **ros**_  
_somos los soldados_  
_de mil novecientos dos._

_Para mi madre le traigo un pañuelo,_  
_para mi padre un sombrero negro._  
_Para mi novia le voy a regalar_  
_zapatitos blancos y medias colorás._

**Cambio a ritmo de jota:**  
_El Rabal es un jardín,_  
_las rabaleras son flores_  
_y los mozos de este pueblo_  
_las cuidan con mil amores._

**_Seguidilla_**  
_A tu madre le pido_  
_y a ti te saco_  
_los cuartos del bolsillo_  
_para tabaco._

_Toda esta calle a lo largo_  
_la tengo que acordonar_  
_con cordones amarillos_  
_de la Virgen del Pilar._

**_Seguidilla_**  
_Arrincónamela_  
_y échamela al rincón._  
_Si es casada, casada,_  
_y si es soltera, mejor._

_Ayer pasé por tu puerta_  
_y me tiraste un limón._  
_El limón me dio en el pecho,_  
_y el agrio en el corazón._

**_Seguidilla_**  
_Al salir el sol_  
_te quisiera ver,_  
_pero veo, niña,_  
_que no puede ser._

_Mi novia vive en el río,_  
_yo vivo en Rincón del Roble._  
_Cada vez que voy a verla_  
_dice que me quiere el doble._

**_Seguidilla_**  
_Y a tu padre, morena,_  
_se lo voy a decir,_  
_que te ves con el Cabo_  
_ de la Guardia Civil._

**_Despedida_**  
_Ya os doy la despedida;_  
_no os la quisiera dar_  
_porque nunca me ha gustado_  
_en un baile quedar mal._

