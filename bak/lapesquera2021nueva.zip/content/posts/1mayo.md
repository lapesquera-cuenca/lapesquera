---
title: el 1º de mayo
date: 2020-05-01T18:48:12+01:00
lastmod: 2020-05-01T18:48:12+01:00
author: Crescencio Martinez
avatar: /img/author.jpg
# authorlink: https://author.site
cover: /img/coverMayos.jpg
categories:
  - primavera
tags:
  - mayos
  - musica
draft: true
---


## Noche de los Mayos del 30 de abril al 1 de mayo 

El día 30 de abril a las doce de la noche y al toque de campanas se reúnen en la puerta de la iglesia los vecinos del pueblo, familiares y amigos que desean cantarle el Mayo a la Virgen de la Cueva Santa. Y es así como se inicia el canto del Mayo.

![](/img/mayonoche.jpg)  
<cite>Cantando los mayos a la Virgen en la Puerta de la Iglesia de La Pesquera</cite>

solitario, al cual se le llama el pintor, va cantando estrofa por estrofa y el personal asistente repite cantando lo mismo que él. No sé quién sería el compositor de la sencilla letra de este Mayo pero al repasarla, te das cuenta con el respeto y delicadeza que escribió cada palabra. Se inicia su canto dando gracias a Dios y se continúa destacando las múltiples gracias y virtudes de la Virgen, con las peticiones que se ruega conceda. A la Virgen se le dedica su Mayo, que es San José y para finalizar, la despedida, cantándole sutiles alabanzas. Cantando los Mayos a la Virgen en la Puerta de la Iglesia de La Pesquera. Normalmente se solía acompañar con su música por uno de los vecinos del pueblo, últimamente lo suele hacer con agrado Eloy Marco con su acordeón. Hasta aquí nada ha cambiado que yo recuerde desde los años 40 al cantar el Mayo a la Virgen. Lo que si se ha dejado de cantar son los Mayos a las mozas, que era una tradición muy esperada por las jóvenes. El Mayo de las mozas, tiene diferente letra que el de la Virgen, pero si la misma entonación melódica. Era generalmente una costumbre por esta región de Castilla, quizás por sus tradicionales rondallas nocturnas, que esa misma noche del 30 de Abril se galanteara a las jóvenes; encontré un Mayo en Albarracín (Teruel), que tiene mucha similitud con el Mayo que se canta en nuestro pueblo. Y el Mayo a las mozas de nuestro pueblo, es de la siguiente manera: Después de terminar el Mayo a la Virgen, una cuadrilla de mozos se ponía de acuerdo para rondar y cantar el Mayo a las mozas, que consistía en elogiar las gracias personales de la moza y nombrarle un posible galán o pretendiente. Era costumbre ir primero a la casa del alcalde, por respeto y autoridad, y después calle por calle y casa por casa, donde se sabía que había mozas, incluso más de una vez se había cantado al matrimonio. Lo primero que se hacía era pedir permiso para cantar el Mayo al amo de la casa y se le decía -¿tío Pedro, quiere usted Mayo ?….- y el tío Pedro o su mujer, respondían, -¡¡ si, cantarlo!! o ¡¡haced lo que queráis!!-, y entonces se cantaba. Hay una anécdota que ha quedado de leyenda, que fue la del tío Eleuterio Zamora, que cuando se le preguntó si quería Mayo, contestó, -¡agosto y septiembre!- ya que en aquellos tiempos, los meses de abril y mayo eran los meses de más penurias del año; accediendo a que se les cantara el Mayo a sus hijas Amparo y Socorro. También es cierto que al cantar el Mayo podría haber alguna sorpresa, como que al nombrarle el galán a la moza, no fuese de su agrado o el que ella esperaba y por consiguiente ya había polémica por la mañana. Y de esta forma llegaba la salida del sol y todavía se estaban cantando Mayos. El cantar el Mayo tenía un precio, que normalmente consistía en pagar con un pan de kilo llamado "Rollo de Mayo" y que las horneras adornaban haciéndole unos cortes muy

![“Rollo de Mayo](/img/rollo-mayo.jpg)

peculiares. "Rollo de Mayo" También se podía pagar con dinero o alguna cosa para comer, lo cual servía para celebrar los mozos su comida en la Fiesta del 1º de Mayo.



## Fiesta del 1º Mayo

Por lo que se refiere a la celebración de éste acontecimiento o costumbre, por lo que he podido averiguar preguntando a las personas de edad avanzada, parece ser que se realizaba una peregrinación a la Cueva Santa por motivos religiosos y de fe popular, donde se reunían en la primera quincena de Mayo los pueblos vecinos, ofreciendo sus exvotos y ofrendas por favores recibidos de la Virgen. Aparte de los actos religiosos, se aprovechaba para pasar el día en harmonía con familiares y amigos. La Cueva Santa está situada en la montaña que hay encima de lo que era la pedanía de la Fuencaliente y que es término de Mira. Se accede por un camino a mitad que parte de la carretera local entre Villargordo del Cabriel y Camporrobles, a mitad de recorrido aproximadamente.

_![Mapa de situación con los pueblos limítrofes.](/img/cueva-santa.jpg)_

Mapa de situación con los pueblos limítrofes.

Se trata de una gruta natural sobre los riscos de la citada montaña y con vistas al río Cabriel, cuya entrada es un pasadizo muy estrecho a través del cual se llega a una explanada interior donde se apareció la Virgen y por lo cual es conocida y venerada y tiene la advocación de LA VIRGEN DE LA CUEVA SANTA.

![Entorno a la entrada a la Cueva con las escaleras metálicas de acceso al fondo. Foto: José Saíz.](/img/cueva-santa-exterior.jpg)

Entorno a la entrada a la Cueva con las escaleras metálicas de acceso al fondo. Celebración de la Romería cada segundo domingo de mayo. Foto: José Saíz.

![interior cueva](/img/interior-cueva.jpg)

Sala interior de la Cueva Santa. <span style="size:">Foto: José Saíz.</span>

En el siglo XVIII, ya sólo realizaban la visita a la citada cueva las gentes de los pueblos de Fuenterrobles, Camporrobles, Villalgordo, La Pesquera, Venta del Moro y Mira, así como su pedanía de la Fuencaliente, en donde se honraba a la Virgen como patrona en la iglesia que estaba situada al lado del manantial de agua caliente o termal, "la balsa de la Fuencaliente". En el interior de la cueva se podía contemplar la belleza de estalactitas y estalagmitas (en la actualidad degradadas), siendo la riqueza biológica y paisajística de éste lugar incomparable. Según otras fuentes, la antigüedad de esta cueva Santuario, data del calcolítico (edad del cobre), considerada Santuario Ibérico; fue convertido del culto pagano al cristianismo en tiempos de La Reconquista, si bien el culto a la Virgen en este lugar data del siglo XIV y alcanzando su máximo apogeo en los siglos XVI y XVII.

![Virgen de la Cueva](/img/virgen-de-la-cueva.jpg)

<span style="size:">Foto: José Saíz.</span>

Imagen de la virgen que se coloca en el interior de la Cueva el día de la Romería de Fuenterrobres

![](/img/cueva-santa-la-pesquera.jpg)

Escarpe rocoso donde se localiza la Cueva Santa visto desde la margen derecha del embalse en las proximidades donde se realiza la actual celebración del "1ª de mayo" en La Pesquera

![](/img/picassent.jpg)

Su imagen se conserva y venera en la localidad de Picassent (Valencia), donde fueron desplazadas la mayoría de las familias de hortelanos del lugar, al quedar inundadas sus casas y bienes por la construcción del pantano de Contreras sobre el río Cabriel. Procesión por los vecinos del barrio de la Fuencaliente en Picassent, antes del canto tradicional del Mayo a la Virgen de la Cueva Santa. En La Pesquera, yo recuerdo siendo muy pequeño, allá por los años 40, el ir a celebrar la fiesta al paraje llamado Las Torcas, que se encuentra donde se unen el camino del Hoyo con la carretera del Pantano. Allí se esperaban el regreso de los que habían ido a la peregrinación a la Cueva Santa y se celebraba la fiesta a la cual ya se unían los mozos que habían cantado los mayos la noche anterior. Para preparar la fiesta de ese día, se solía nombrar a los Mayordomos, que eran escogidos entre los matrimonios celebrados en años anteriores. Estos Mayordomos solían hacer una popular "zurra" o refresco para todos los vecinos que asistían a la fiesta y solían invitar ese día a familiares y amigos a la comida. El resto de los que se quedaban en la fiesta, comían de merienda de "taleguillo", tortilla de patatas y como extra, pisto con conejo o con pollo. De todas formas y aunque los tiempos no daban para muchos dispendios, lo cierto es que con lo poco que se tenía, también se disfrutaba. Yo creo que de aquí viene la popular fiesta que hoy día llamamos la Fiesta del 1º de Mayo. Después se pasó a celebrar la fiesta en el lugar de La Cruz de Beato, esto sería sobre los años sesenta.

![](/img/cruz-del-beato.jpg)

Se colocó una cruz de madera a la orilla del camino y allí se llevaba a la Virgen y se celebraba una misa de cara a la montaña de la Cueva Santa que desde este lugar se divisaba. Recreación de la Cruz del Beato por Crescencio Martínez

Celebración de la fiesta en el paraje de la Cruz del Beato :

![](/img/cruz-del-beato-2.jpg)

![](/img/cruz-del-beato-3.jpg)

A partir de la construcción del pantano de Contreras, la fiesta se viene celebrando en el paraje denominado "1º de Mayo", lugar muy cerca del mismo, con unas maravillosas vistas y a escasos cinco kilómetros del pueblo.

![](/img/los90.jpg)

En el año 1993, en este lugar se ha construido un templete o humilladero donde se coloca a la Virgen que ha sido traída a hombros en romería desde el pueblo. Se oficia la misa y se le vuelve a cantar el Mayo como la noche anterior.

![](/img/celebracion.jpg)

Celebraciones entorno al humilladero.

También se ha equipado el lugar con una fuente de agua potable, servicios y aseos, barbacoas, refugio y zona con numerosas mesas y bancos para poder disfrutar el día con cierta comodidad.

![](/img/chocolate.jpg)


El entorno del lugar, tanto el mantenimiento como su conservación, es gestionado por el Ayuntamiento de La Pesquera. Preparación de las comidas en las zonas acondicionadas para hacer fuego. Actualmente, aunque se ha perdido la costumbre de cantar los Mayos a las mozas y no haber Mayordomos, hacia las once de la mañana y después de la misa, el Ayuntamiento invita a todos los asistentes, como es ya tradicional, con el famoso chocolate y magdalenas. Reparto del chocolate y magdalenas entre todos los asistentes. La fiesta se ha hecho tan popular, que es unas de las mayores concentraciones de toda la comarca, compartiendo con familiares y conocidos sus suculentas paellas,

![](/img/1mayo-lugar-(3).jpg)

parrilladas de carne y chorizos, sus deliciosos postres y dulces, sin faltar el buen café y abundantes bebidas, prolongándose la alegría y jolgorio hasta muy avanzada la tarde, ocasión que aprovechan algunos para finalizar con una buena cena. Deseo y espero que con estas narraciones, a muchas personas les vuelvan a la memoria, con cierta nostalgia, recuerdos de lo vivido y si es así, me alegro y lo celebro, para que de esta forma no quede en el olvido parte de nuestra identidad. Y si recordamos…, vivimos.



## Bibliografía

Fotografías: Crescencio Martínez Navarro, Óscar Serrano, José Saíz Valero, Gregorio Murciano y Miguel Ángel Martínez Palomares.

La Cueva Santa del Cabriel: Aproximación a la evolución histórica-religiosa del Santuario y de la imagen allí venerada: Fernando Moya Muñoz, Ayuntamiento de Fuenterrobles, 1998\. 201 páginas  

La Cueva Santa del Cabriel (Mira, Cuenca), Lugar de culto antiguo y ermita cristiana: Alberto J. LORRIO, Teresa MONEO, Fernando MOYA, Sara PERNAS y Mª Dolores SÁNCHEZ DE PRADO, Revista Complutum, 2006, Vol. 17: pp. 45-80\.

