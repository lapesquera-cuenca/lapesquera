---
title: Letra de los Mayos
date: 2020-05-01T18:48:12+01:00
lastmod: 2020-05-01T18:48:12+01:00
author: Crescencio Martinez
avatar: /img/author.jpg
# authorlink: https://author.site
cover: /img/mayo-canto.jpg
categories:
  - primavera
tags:
  - mayos
  - musica
draft: true
---
## Mayo que se canta cada 30 de abril a las 12 de la noche en las puertas de la iglesia de La Pesquera.
![](/img/mayo-canto.jpg)  



Gracias a Dios que he llegado  
a la puerta de este Templo,  
donde está la Virgen Pura  
y el Santísimo Sacramento.  
  
Gracias a Dios que he llegado  
a la puerta de los cielos  
y el coro celestial  
y de los  ángeles bellos.  
  
Con el favor de Jesús  
y de la Virgen Sagrada  
a la puerta de este templo  
demos la primera entrada.  
  
Y después de haberla dado  
con alegría y contento,  
hagamos la reverencia  
al Santísimo Sacramento.  
  
Y así para proseguir  
de vuestro mayo al principio  
le pido a la celestial  
Aurora del Sol divino.  
  
Amparo, favor y gracia  
que con este patrocinio  
pueda mi constante pluma  
sacar este caso en limpio.  
  
Atención, noble auditorio,  
tu silencio necesito;  
a tus plantas Virgen Pura,  
llego rendido y postrado.  
  
Suplico me deis licencia,  
para cantaras el mayo.  
Licencia te pido a Tí  
y a tu Padre Soberano.  
  
Y a tu santo y sabio hijo  
y al Espíritu Santo,  
para que con la licencia  
de este misterio sagrado.  
  
Prosiga yo sin temor  
a cantaros vuestros mayos  
  
Detente, noche y no corras  
detened hermosos astros,.  
  
Parad estrellas lucientes  
y parad luceros claros .  
Escuchad que de María  
son luces, luceros y astros.  
  
Vamos a cantar las glorias  
en esta noche de mayo.  
Pero antes, dulce Señora,  
es preciso saludaros.  
  
Como lo hizo San Gabriel  
aquel arcángel sagrado,  
diciéndoos ,salve María,  
salve Dolorosa y nardo.  
  
Salve, Reina de los cielos,  
Madre del Verbo encarnado.  
  
![](/img/mayodia.jpg)  
(* cambio de tono)  
Con las tres personas  
y el Verbo divino  
y tu santa gracia  
daremos principios.  
  
El querer del Padre  
y el amor del hijo  
y del Espíritu Santo  
nos darán auxilio.  
  
A Tí, Virgen Santa,  
Reina del imperio  
como madre nuestra  
tu favor pedimos.  
  
Pues siendo esta antorcha  
podremos deciros  
dos mil parabienes  
y grandes prodigios.  
  
Oh feliz recurso  
oh dichosa rueda,  
que vas descendiendo  
de esfera en esfera.  
  
Donde abril concluye  
y mayo comienza  
bienvenido mayo,  
bienvenido seas.  
  
Alfombras bordando  
para las doncellas ;  
claveles y lirios,  
blancas azucenas.  
  
Prometiendo frutos  
con sus flores bellas,  
Señor de los campos,  
dueño de las ciencias.  
  
Primavera dulce,  
hermosa floresta,  
pues, Señor del año  
tu vos me confiesa;  
  
Supuesto que bordas  
las heladas selvas  
con rayos de luz,  
que alumbran la tierra.  
  
Discreta y afable  
de hermosura bella;  
y una sobresale  
de entre todas ellas.  
  
De rosario ,Madre,  
María es aquella  
y, ahora, Señora,  
si me dais licencia  
  
cantaré las gracias  
de tus permanencias.  
Divina María, dulce Reina,  
Excelsa, más pura que el sol  
y que las estrellas.  
  
Aquellos dos rayos  
de la luna bella  
sirven de contorno  
a tus plantas bellas.  
  
Ciprés levantado  
de tanta excelencia,  
que llegaste al cielo  
con la ciencia, ciencia,  
Cumbrada de palmas,  
  
que a Vos representa;  
de vuestras virtudes  
la mayor pureza.  
  
Jardín delicioso,  
donde se recrea  
tu esposo José,  
al ver tu belleza.  
  
Con tantos favores  
turbada te quedas.  
Y el ángel repite,  
Señora, no temas.  
Te quedarás Virgen  
y la fe no pierdas,  
que estos son favores  
de la ciencia, ciencia.  
  
Y aquí respondiste  
con gran humildad,  
si el Señor lo manda,  
sea su voluntad.  
  
Y ahora os pedimos,  
pues sois nuestra Madre,  
con afecto puro  
deciros la salve.  
  
(* cambio de tono)  
  
Dios te salve de los cielos  
Reina heroica y admirable,  
Madre de piedad y fuente  
de misericordia grande.  
  
Vida por la cual pedimos  
dulzura de nuestros males,  
esperanza en quien se mira  
nuestra dicha increditable.  
   
Dios te salve, a Tí llamamos  
los desterrados, oh Madre,  
siendo todos hijos de Eva  
suspiramos nuestros males.  
  
También gimiendo y llorando  
por los pecados mortales;  
y aquí nos tenéis, Señora,  
de lágrimas en un valle.  
  
Ea pues, nuestra Abogada,  
vuelve a nosotros, afable,  
esos misericordiosos  
ojos tuyos deleitables  
  
Después de aquí, este destierro,  
muéstranos, divina Madre,  
a Jesús, fruto bendito,  
de tu vientre sol brillante.  
  
Oh Clementísima Aurora,  
oh Piadosa y Tierna Madre,  
oh Dulce Virgen María,  
que a un solo Dios agradaste.  
  
Ruega por los medianeros  
de los hombres, santa Madre,  
para que seamos dignos  
de alcanzar las más afables  
promesas de Jesucristo  
  
por siglos y eternidades.  
  
(* cambio de tono)  
Y, ahora, Señora,  
Virgen del Rosario,  
prosigo diciendo  
quien es vuestro mayo  
  
Un casto mancebo  
de virtud muy alta  
que humilde te pide  
por esposa y maya  
  
Quien sube a la meta  
su virtud merece,  
pues estando seco  
luego reverdece  
Pues si estas herida  
de esta dulce flecha  
San José bendito  
de mayo se os echa.  
  
Para vuestro agrado  
recibidlo, Reina,  
las gracias os damos:  
sea enhorabuena.  
  
Sea enhorabuena  
dicha tan gloriosa,  
que fuiste escogida  
de Dios por Esposa.  
  
(* cambio de tono)  
  
Que me perdonéis te pido  
una y mil veces, Señora,  
mi sobrado atrevimiento;  
que Dios todo lo perdona.  
  
Y, si merezco el perdón,  
me ofrezco a ser tu esclavo,  
y si no, seré en el mundo  
el hombre más desdichado.  
  
Siempre al cielo rogaré  
que nos envíe buen año  
de pan, vino y aceite;  
que estamos necesitados.  
  
Y las pobres criaturas  
te lo suplican llorando.  
Ya es tiempo, Virgen María,  
que me vaya de este templo,  
porque ya no puedo mas  
pasar adelante mi intento.  
  
Adiós Paloma divina,  
adiós celestial amparo,  
adiós ,Virgen del Rosario;  
de tu puerta me despido  
  
  
Hasta llegar a otro año  
Con el gozo y el contento  
de haberos cantado el mayo  
Adiós, Virgen Pura  
  
Adiós, Virgen Madre,  
adiós, Virgen Bella,  
amén, amén ,amén, ...   