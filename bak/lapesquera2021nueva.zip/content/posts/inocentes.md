---
title: Los Inocentes 28 de diciembre
date: 2020-12-28T18:48:12+01:00
lastmod: 2020-12-28T18:48:12+01:00
author: Crescencio Martinez
avatar: /img/author.jpg
# authorlink: https://author.site
cover: /img/coverInocentes.jpg
categories:
  - invierno
tags:
  - tradiciones perdidas
  - musica
draft: true
---

Esta fiestá dejó de celebrarse sobre los años sesenta del siglo XX.

![La pared de la horca en los años 60](/img/pared.jpg) 

Generalmente y desde tiempos ancestrales, todos los pueblos celebran algún acontecimiento relacionado con sus costumbres, festejos populares o fiestas patronales. LA PESQUERA , no podía ser menos.

Por lo tanto, recordando uno de nuestros festejos populares y que dejó de celebrarse allá sobre los años sesenta, no he querido que quedara en el olvido y por lo cual voy a intentar narrar lo más fielmente que pueda, ésta fiesta que se celebraba en nuestro pueblo el día 28 de diciembre. LOS SANTOS INOCENTES .

![Horca sobre la pared de la Iglesia](/img/horca.jpg)

La fiesta era realizada por los mozos del mismo reemplazo, que previamente habían sido alistados y tallados para realizar el obligatorio servicio militar al año siguiente: “LOS QUINTOS ”. Ese día, los quintos, (que festivamente se consideraban autoridades) y a los cuales denominaban “ALCALDES ”, lo primero que hacían de madrugada era preparar “LA HORCA ”, la cual consistía en apoyar sobre la pared lateral de la iglesia dos troncos de pino un poco inclinados verticalmente, y unidos en su parte superior con cuerdas a otro tronco en horizontal en cuyo centro de éste tronco se colocaba una “GARRUCHA ”, por la que se hacía pasar una soga gruesa de esparto que servía (figuradamente) para subir y bajar a los “AHORCADOS ”. Horca sobre la pared de la Iglesia

![Sombrero de Alcalde](/img/sombrero.jpg)

Los quintos-alcaldes se caracterizaban porque llevaban un sombrero, al cual se le habían cosido en la parte posterior muchas cintas de diferentes colores, detalle realizado por las novias, amigas o familia de los mismos, por lo que a veces se competía en quien hacia el sombrero con más cintas y más bonitas. El cometido de los alcaldes era estar a la orden y peticiones de las personas que los solicitaban. Por la mañana se situaban alrededor de la horca y cualquier persona que les dijeren u ofreciese unas monedas, tenían que intentar hacer lo que les mandaban. -Cincuenta céntimos para que subáis a la horca a fulano o menganita(que entonces había salido a la calle o pasaba por allí)- entonces uno de los alcaldes salía corriendo y lo detenía: -Han pagado cincuenta céntimos para que te subamos a la horca.- Esta persona, si no quería que lo subieran tenía que pagar lo mismo que le habían ofrecido o algo más si hacia réplica. Normalmente los varones se dejaban atar con la soga que tenían en la horca por la cintura y que lo subieran unos metros. Con las mujeres era distinto, éstas solían pagar y replicar, -cinco céntimos más para que ahorquéis al que ha ofrecido por mí-. En raras ocasiones se dieron las circunstancias de subir a una mujer a la horca y si alguna vez ocurrió, jamás la subieron más de un metro, ya que en aquellos tiempos, las mujeres no acostumbraban a llevar pantalones y se debía respetar su honestidad.

![El Carántula](/img/alcalde.jpg)

Éste espectáculo duraba por la mañana hasta la salida de misa, cuyo acto había sido solicitado y pagado por los quintos y que algunos de ellos la presidian. Cuando se salía de oír misa, la horca ya estaba quitada. A parte de los alcaldes, había un personaje muy particular y grotesco, era “EL CARÁNTULA ”. Uno de los quintos (normalmente el más bromista o botarga), iba disfrazado de una forma bastante rara. Llevaba la cara pintada de negro con hollín, un sombrero hecho de “PLAITA ”, vestido con una “ZAMARRA ” de piel de oveja, pantalones con remiendos y a los que habían cosido canutos de caña, calzado con albarcas y colgados en su espalda unos cencerros, con lo cual armaba el gran alboroto.

También llevaba una “CAPACHA ” o morral y una escobilla con mango corto. La misión de este personaje fantoche era ir de casa en casa, sin hablar, para no ser reconocido, se dirigía a los dueños y con la escobilla se la pasaba por los hombros como si les quitara el polvo, hasta conseguir algún presente (chorizos, morcillas, patatas o lo que fuese…), lo que le daban se lo metía en la capacha, y a otra casa. Así toda la mañana.

Al mediodía, para la comida, mataban a un cordero que ellos mismos guisaban y que junto con lo que habían recogido, hacían la gran “FRANCACHELA ” regada con abundante vino.

![Foto. Asunción Palomares.](/img/inocentes.jpg) 

Amparete, Asuncion, Elisa, Carmen, Josefina, Crescencio (El Rubio) y Antonio.

Por la tarde, seguía la fiesta. Los quintos también pagaban a un músico acordeonista y después de comer se recorría el pueblo calle por calle con la música de acordeón y de vez en cuando se hacía una parada. De la misma forma que por la mañana los alcaldes realizaban su cometido en la horca, por la tarde era en el baile, -Una peseta para que baile María con Pedro (seguramente estaban enfadados o no se hablaban)- incluso se hacía bailar a personas del mismo sexo o enemistados o a las más remilgadas se les obligaba a bailar con el carántula. La fiesta concluía con el baile de tarde y noche en el local habitual. Y aunque hubiese algún disgustillo, todo acababa sin mayor importancia. Las mozas también se lo pasaban muy bien, solo había que oírlas, -He bailado dos piezas con Luís, y me ha puesto su sombrero-. Con el deseo de que este simple relato de uno de los festejos populares de nuestro pueblo LA PESQUERA , sirva para recordar sueños e ilusiones de juventud a todos aquellos que vivimos y disfrutamos momentos tan agradables y difíciles de olvidar. También para aquellos que no los vivisteis, hoy tiempo y circunstancias diferentes, pero tenéis lo mejor, vuestra juventud, no menso buena que la nuestra.